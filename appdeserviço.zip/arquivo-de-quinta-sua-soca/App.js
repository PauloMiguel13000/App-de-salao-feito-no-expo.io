import { Fragment } from 'react';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import React, { Component } from 'react';

import {
  Text,
  StyleSheet,
  ScrollView,
  InputAccessoryView,
  View,
  TextInput,
  Image,
  TouchableOpacity,
  Dimensions,
  Permissions,
  Location,
  ScaledSize,
  Alert,
  Platform,
  ImageBackground,
  SafeAreaView,
} from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import MapView from 'react-native-maps';

class HomeScreen extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/make.png')}
        style={{ width: '100%', height: '100%' }}>
        <View style={styles.container}>
          <Image style={styles.logo} source={require('./assets/logohi.png')} />
          <Image
            style={styles.logo1}
            source={require('./assets/female-hairs.png')}
          />
          <TouchableOpacity
            style={styles.button}
            onPress={() =>
              Alert.alert(
                'Login',

                'Confirmar seu login?',
                [
                  {
                    text: 'Sim',
                    onPress: () => this.props.navigation.navigate('Details'),
                  },

                  {
                    text: 'Não',
                    onPress: () => Alert.alert('voltando para o login'),
                  },
                ],
                { cancelable: false }
              )
            }>
            <Text style={styles.botaoText}> May Makeup 1.0 </Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    );
  }
}

class Miguel extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/fundo make.png')}
        style={{ width: '100%', height: '100%' }}>
        <ScrollView vertical>
          <View style={styles1.container}>
            <Image
              style={styles1.logo}
              source={require('./assets/cliente.png')}
            />
            <Image
              style={styles1.logo1}
              source={require('./assets/sobrinha.png')}
            />
            <Image
              style={styles1.logo2}
              source={require('./assets/cliente1.png')}
            />
            <Image
              style={styles1.logo3}
              source={require('./assets/cliente2.png')}
            />

            <Image
              style={styles1.logo4}
              source={require('./assets/cliente4.png')}
            />

            <Text> May Makeup </Text>

            <TouchableOpacity style={styles1.botao}>
              <Button
                style={styles1.botao}
                title="voltar"
                onPress={() => this.props.navigation.goBack()}
                color="#841584"
              />

              <Text style={styles.botaoText} />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }
}
class Miguel3 extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/background-rosa.png')}
        style={{ width: '100%', height: '100%' }}>
        <ScrollView vertical>
          <View style={styles7.container}>
            <Fragment>
              <SafeAreaView style={{ flex: 0, backgroundColor: 'red' }} />
              <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
                <Text style={{ color: '#121313' }}>
                  Olá meu nome é May! Sou esteticista e trabalho com maquiagem e
                  cabelo á 4 anos,e não a nada mais gratificante que ver o
                  sorriso de alguém ao se olhar no espelho e se ver ainda mais
                  linda. Trabalhar com beleza é uma forma de transformar a vida
                  das pessoas e fazer elas acreditarem na sua beleza interior,
                  de dentro para fora. É por esse motivo que decidir expor pra
                  você cada detalhe e cada traço daquilo que sei de melhor,
                  espero encantar você, como me encanto a cada vez que tenho a
                  oportunidade de transformar vidas.{' '}
                </Text>
              </SafeAreaView>

              <SafeAreaView />
            </Fragment>
            <Fragment>
              <Fragment>
                <SafeAreaView style={{ flex: 0, backgroundColor: 'red' }} />
                <SafeAreaView style={{ flex: 1, backgroundColor: 'pink' }}>
                  <Text style={{ color: '#121313' }} />
                </SafeAreaView>

                <SafeAreaView />
              </Fragment>

              <SafeAreaView />
            </Fragment>
            <Fragment>
              <Fragment>
                <SafeAreaView style={{ flex: 0, backgroundColor: 'red' }} />
                <SafeAreaView style={{ flex: 1, backgroundColor: 'pink' }}>
                  <Text style={{ color: '#121313' }} />
                </SafeAreaView>

                <SafeAreaView />
              </Fragment>

              <SafeAreaView />
            </Fragment>
            <Fragment>
              <Fragment>
                <SafeAreaView style={{ flex: 0, backgroundColor: 'red' }} />
                <SafeAreaView style={{ flex: 1, backgroundColor: 'pink' }}>
                  <Text style={{ color: '#121313' }} />
                </SafeAreaView>

                <SafeAreaView />
              </Fragment>

              <SafeAreaView />
            </Fragment>
            <Fragment>
              <SafeAreaView style={{ flex: 0, backgroundColor: 'red' }} />
              <SafeAreaView style={{ flex: 1, backgroundColor: 'black' }}>
                <Text style={{ color: '#fff' }}>Numero:7391271898 </Text>
                <Text style={{ color: '#fff' }}>
                  Email:maymakeup2019@gmail.com{' '}
                </Text>
              </SafeAreaView>
            </Fragment>

            <TouchableOpacity style={styles7.botao}>
              <Button
                style={styles7.botao}
                title="voltar"
                onPress={() => this.props.navigation.goBack()}
                color="#841584"
              />

              <Text style={styles7.botaoText} />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }
}
class Miguel2 extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/layout cabelo.png')}
        style={{ width: '100%', height: '100%' }}>
        <ScrollView vertical>
          <View style={styles1.container}>
            <Image
              style={styles1.logo}
              source={require('./assets/cabelo.png')}
            />
            <Image
              style={styles1.logo1}
              source={require('./assets/cabelo1.png')}
            />
            <Image
              style={styles1.logo2}
              source={require('./assets/cabelo2.png')}
            />
            <Image
              style={styles1.logo3}
              source={require('./assets/cabelo3.png')}
            />

            <Image
              style={styles1.logo4}
              source={require('./assets/cabelo4.png')}
            />

            <TouchableOpacity style={styles1.botao}>
              <Button
                style={styles1.botao}
                title="voltar"
                onPress={() => this.props.navigation.goBack()}
                color="#841584"
                type="Clear"
              />

              <Text style={styles.botaoText} />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }
}

class Maps extends Component {
  state = {
    latitude: -12.9708409,
    longitude: -38.4762857,
  };
  render() {
    const { latitude, longitude } = this.state;

    return (
      <View style={styles3.container}>
        <MapView
          initialRegion={{
            latitudeDelta: 0.0042,
            longitudeDelta: 0.0031,
          }}
          style={styles3.mapView}>
          <MapView.Marker
            coordinate={{
              latitude: -12.9708409,
              longitude: -38.4762857,
            }}
          />
        </MapView>
        <ScrollView style={styles3.placesContainer} vertical>
          <View style={styles3.place} />
          <View style={styles3.place} />
        </ScrollView>
        <TouchableOpacity
          style={{ width: 30, height: 30, margin: 30 }}
          styles={styles.botao}>
          <Button
            title="Ache-se"
            onPress={() => this.props.navigation.navigate('Mapa')}
            loading
            type="outline"
          />
          <Text style={styles.botaoText}>...</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
class Mapa extends Component {
  render() {
    return (
      <MapView
        initialRegion={{
          latitude: -12.9708409,
          longitude: -38.4762857,
          latitudeDelta: 0.0042,
          longitudeDelta: 0.0031,
        }}
        style={styles5.mapView}>
        <MapView.Marker
          coordinate={{
            latitude: -12.9708409,
            longitude: -38.4762857,
          }}
        />
      </MapView>
    );
  }
}

class DetailsScreen extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/vida.png')}
        style={{ width: '100%', height: '100%' }}>
        <View style={{ flex: 1, justifyContent: 'center' }}>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 50 }} />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Maquiagens"
              onPress={() => this.props.navigation.navigate('Miguel')}
            />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Cabelo"
              onPress={() => this.props.navigation.navigate('Miguel2')}
            />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="contato"
              onPress={() => this.props.navigation.navigate('Miguel3')}
            />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Voltar"
              onPress={() => this.props.navigation.goBack()}
            />
          </View>
        </View>
      </ImageBackground>
    );
  }
}

const AppNavigator = createStackNavigator(
  {
    Home: {
      screen: HomeScreen,
    },

    Details: {
      screen: DetailsScreen,
    },

    Miguel: {
      screen: Miguel,
    },
    Maps: {
      screen: Maps,
    },
    Mapa: {
      screen: Mapa,
    },
    Miguel2: {
      screen: Miguel2,
    },
    Miguel3: {
      screen: Miguel3,
    },
  },

  {
    initialRouteName: 'Home',
  }
);

const styles = StyleSheet.create({
  container: {
    marginTop: 350,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 250,
    marginTop: -285,
    height: 250,
  },
  logo1: {
    width: 100,
    marginTop: 88,
    height: 100,
    borderRadius: 170,
  },
  botaoText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'rgba(192,38,41,1.0)',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alighItems: 'center',
    textAlign: 'center',
    marginTop: 150,
  },
  button: {
    width: 120,
    height: 120,
    marginTop: -109,
    margin: 0,
    alighItems: 'space-between',
    backgroundColor: 'rgba(247,141,167,0.6)',
    borderRadius: 170,
  },
});
const styles1 = StyleSheet.create({
  container: {
    marginTop: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    margin: 20,
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  logo1: {
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  logo2: {
    margin: 20,
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  logo3: {
    margin: 20,
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  logo4: {
    margin: 20,
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  botao: {
    margin: 10,
    width: 300,
    height: 200,
  },
});
const styles7 = StyleSheet.create({
  container: {
    marginTop: 170,
    justifyContent: 'center',
    alignItems: 'center',
  },

  botao: {
    width: 150,
    height: 150,

    margin: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const { height, width } = Dimensions.get('window');

const styles3 = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  mapView: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});
const styles5 = StyleSheet.create({
  mapView: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});

const AppContainer = createAppContainer(AppNavigator);

export default class App extends Component {
  render() {
    return <AppContainer />;
  }
}
